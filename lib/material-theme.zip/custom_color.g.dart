import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/material.dart';

const #fcba03 = Color(0xFF532C92);


CustomColors lightCustomColors = const CustomColors(
  source-#fcba03: Color(0xFF532C92),
  #fcba03: Color(0xFF6F49AF),
  on-#fcba03: Color(0xFFFFFFFF),
  #fcba03Container: Color(0xFFEBDCFF),
  on-#fcba03Container: Color(0xFF270058),
);

CustomColors darkCustomColors = const CustomColors(
  source-#fcba03: Color(0xFF532C92),
  #fcba03: Color(0xFFD4BBFF),
  on-#fcba03: Color(0xFF3F127E),
  #fcba03Container: Color(0xFF562F95),
  on-#fcba03Container: Color(0xFFEBDCFF),
);



/// Defines a set of custom colors, each comprised of 4 complementary tones.
///
/// See also:
///   * <https://m3.material.io/styles/color/the-color-system/custom-colors>
@immutable
class CustomColors extends ThemeExtension<CustomColors> {
  const CustomColors({
    required this.source-#fcba03,
    required this.#fcba03,
    required this.on-#fcba03,
    required this.#fcba03Container,
    required this.on-#fcba03Container,
  });

  final Color? source-#fcba03;
  final Color? #fcba03;
  final Color? on-#fcba03;
  final Color? #fcba03Container;
  final Color? on-#fcba03Container;

  @override
  CustomColors copyWith({
    Color? source-#fcba03,
    Color? #fcba03,
    Color? on-#fcba03,
    Color? #fcba03Container,
    Color? on-#fcba03Container,
  }) {
    return CustomColors(
      source-#fcba03: source-#fcba03 ?? this.source-#fcba03,
      #fcba03: #fcba03 ?? this.#fcba03,
      on-#fcba03: on-#fcba03 ?? this.on-#fcba03,
      #fcba03Container: #fcba03Container ?? this.#fcba03Container,
      on-#fcba03Container: on-#fcba03Container ?? this.on-#fcba03Container,
    );
  }

  @override
  CustomColors lerp(ThemeExtension<CustomColors>? other, double t) {
    if (other is! CustomColors) {
      return this;
    }
    return CustomColors(
      source-#fcba03: Color.lerp(source-#fcba03, other.source-#fcba03, t),
      #fcba03: Color.lerp(#fcba03, other.#fcba03, t),
      on-#fcba03: Color.lerp(on-#fcba03, other.on-#fcba03, t),
      #fcba03Container: Color.lerp(#fcba03Container, other.#fcba03Container, t),
      on-#fcba03Container: Color.lerp(on-#fcba03Container, other.on-#fcba03Container, t),
    );
  }

  /// Returns an instance of [CustomColors] in which the following custom
  /// colors are harmonized with [dynamic]'s [ColorScheme.primary].
  ///   * [CustomColors.source-#fcba03]
  ///   * [CustomColors.#fcba03]
  ///   * [CustomColors.on-#fcba03]
  ///   * [CustomColors.#fcba03Container]
  ///   * [CustomColors.on-#fcba03Container]
  ///
  /// See also:
  ///   * <https://m3.material.io/styles/color/the-color-system/custom-colors#harmonization>
  CustomColors harmonized(ColorScheme dynamic) {
    return copyWith(
      source-#fcba03: source-#fcba03!.harmonizeWith(dynamic.primary),
      #fcba03: #fcba03!.harmonizeWith(dynamic.primary),
      on-#fcba03: on-#fcba03!.harmonizeWith(dynamic.primary),
      #fcba03Container: #fcba03Container!.harmonizeWith(dynamic.primary),
      on-#fcba03Container: on-#fcba03Container!.harmonizeWith(dynamic.primary),
    );
  }
}